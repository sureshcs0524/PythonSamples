#region Loading packages
import json
from Card import Card
from Player import Player
import random
import logging
#endregion

#region Loading the json files into the class objects
cards = []
with open('Characteristic.json') as json_file:
	data = json.load(json_file)
	for p in data['characteristic']:
		cards.append(Card(p['name'], p['id'], p['value']))

#endregion

#region Global variables
players = []
playersDieValue = []
deck = []
machineGame = False
#endregion

#region Different funtions to support the our game

#region Rolling of Die logic


def dieRollingForPlayers():
	logging.info("dieRollingForPlayers Started")
	rollWinPlayer = ""
	try:
		for player in players:
			if machineGame:
				plyDie = "1"
			else:
				print(
					"Welcome :" + player.Name + ". To start the Game roll your die, press 1 for start press 2 for exit")
				plyDie = input()

			if plyDie == "1":
				rn_playersDieValue = random.randint(1, 6)
				print("The die value for player :" + player.Name + " is : " + str(rn_playersDieValue))
				playersDieValue.append(rn_playersDieValue)

			else:
				print("Your are exited from the Game.")
				break

		if len(playersDieValue) == 2:
			player1, player2 = players
			if playersDieValue[0] > playersDieValue[1]:
				print(player1.Name + " has won the die val, Please start the game!")
				rollWinPlayer = player1.Id
			else:
				print(player2.Name + " has won the die val1ue, Please start the game!")
				rollWinPlayer = player2.Id
		else:
			print(" Players are not chosen to opt the game start")
			raise Exception("Players are not chosen to opt the game start")

	except Exception as ex:
		print("Something went wrong: " + str(ex))
		raise Exception("Players are not chosen to opt the game start")

	logging.info("dieRollingForPlayers Ended")

	return rollWinPlayer
#endregion


#region Distribution cards from the class objects


def distributeCards():
	logging.info("distributeCards Started")
	try:
		rawDeck = cards
		usedCards = []
		if len(cards) > 0:
			player1, player2 = players

		valDis = len(cards) / 2
		random.shuffle(cards)

	# deal five cards to player 1
		for i in range(int(valDis)):
			drawnCard = random.choice(rawDeck)
			print(drawnCard.Id)
			usedCards.append(drawnCard.Id)
			rawDeck = [f for f in rawDeck if f.Id not in usedCards]
			player1.CardDetails.append(drawnCard)

	# repeat the process for player 2
		for i in range(int(valDis)):
			drawnCard = random.choice(rawDeck)
			print(drawnCard.Id)
			usedCards.append(drawnCard.Id)
			player2.CardDetails.append(drawnCard)
			rawDeck = [f for f in rawDeck if f.Id not in usedCards]

	except Exception as ex:
		print("Something went wrong: " + str(ex))
		raise Exception("Something went wrong distributeCards")

	logging.info("distributeCards Ended")
#endregion


#region Spell check conditons for Godspell on wining the round


def spellCheckCondition(player1, player2):
	logging.info("spellCheckCondition Started")
	try:
		print("Enter 1, 2 and 3 for God Spell, Resurrect Spell and Continue the game respectively. God spell possible only,"
		  " if you win from the previous round or rolls of die")
		spell = input()
		if spell == int("1"):
			if player1.WonRound or player2.WonRound:
				return spell
			else:
				print("You are not authorised to enter the God spell.")
				return "0"
		else:
			return spell
	except Exception as ex:
		print("Something went wrong: " + str(ex))
		raise Exception("Something went wrong in spellCheckCondition")

	logging.info("spellCheckCondition Ended")

#endregion


#region Calling Godspell logic with game Design


def callGodSpell(player1, player2):
	logging.info("callGodSpell Started")
	try:
		if player1.WonRound:
			print("{0},You have chosen for God Spell.".format(player1.Name))
			print(
				"Do you wish continue {0} to go for normal flow or God Spell flow? Enter values 1 or 2 respectively".format(
					player2.Name))
			spellOption = input()

			if spellOption == "1":
				normalFlow(player1, player2)
			elif spellOption == "2":
				if machineGame:
					player2Spell = str(random.randint(1, 2))

				else:
					print(
						"{0}, Do you wish  to go for god spell flow or Resurrect spell? Enter values 1 or 2 respectively".format(
							player2.Name))
					player2Spell = input()

				if player2Spell == "1":
					print("Total number of cards in the {0}  deck is :".format(player2.Name) + str(
						len(player2.CardDetails)))
					if player1.GodSpellCount == 0:
						if machineGame:
							player2sGodSpellCard = str(random.randint(1, len(player2.CardDetails)))
						else:
							print("Choose the card number from his/her deck!")
							player2sGodSpellCard = input()

						player2.CardDetails[0], player2.CardDetails[int(player2sGodSpellCard) - 1] = \
						player2.CardDetails[int(player2sGodSpellCard) - 1], player2.CardDetails[0]
						normalFlow(player1, player2)
						player1.GodSpellCount += 1
					else:
						print("Only one time we could use God Spell")
						return False

				elif player2Spell == "2":
					if player1.ResurrectSpellCount == 0:
						callResurrectSpell(player1, player2)
						player1.ResurrectSpellCount += 1
					else:
						print("Only one time we could use Resurrect Spell")
						return False

		elif player2.WonRound:
			print("{0},You have chosen for God Spell.".format(player2.Name))

			if machineGame:
				spellOption = str(random.randint(1, 2))
			else:
				print("Do you wish {0} to go for normal flow or God spell? Enter values 1 or 2 respectively".format(
					player1.Name))
				spellOption = input()

			if spellOption == "1":
				normalFlow(player1, player2)
			elif spellOption == "2":

				if machineGame:
					player1Spell = str(random.randint(1, 2))
				else:
					print(
						"{0}, Do you wish  to go for god spell flow or Resurrect spell? Enter values 1 or 2 respectively".format(
							player1.Name))
					player1Spell = input()

				if player1Spell == "1":
					print("Total number of cards in the {0}  deck is :".format(player1.Name) + str(
						len(player1.CardDetails)))
					if player2.GodSpellCount == 0:
						if machineGame:
							player1sGodSpellCard = random.randint(1, len(player2.CardDetails))
						else:
							print("Choose the card number from his/her deck!")
							player1sGodSpellCard = input()

						player1.CardDetails[0], player1.CardDetails[int(player1sGodSpellCard) - 1] = \
						player1.CardDetails[int(player1sGodSpellCard) - 1], player1.CardDetails[0]
						normalFlow(player1, player2)
					else:
						print("Only one time we could use God Spell")
						return False
				elif player1Spell == "2":
					if player2.ResurrectSpellCount == 0:
						callResurrectSpell(player1, player2)
						player2.ResurrectSpellCount += 1
					else:
						print("Only one time we could use Resurrect Spell")
						return False
		else:
			print("Game ended")
			return False
	except Exception as ex:
		print("Something went wrong: " + str(ex))
		raise Exception("Something went wrong in callGodSpell")

	logging.info("callGodSpell Ended")
	return True
#endregion


#region Calling ResurrectSpell logic with game Design


def callResurrectSpell(player1, player2):
	logging.info("callResurrectSpell Started")
	try:
		if player1.WonRound:
			print("{0},You have chosen for Resurrect Spell.".format(player1.Name))
			print(
				"Do you wish {0} to go for normal flow or Resurrect Spell flow? Enter values 1 or 2 respectively".format(
					player2.Name))
			spellOption = input()

			if spellOption == "1":
				normalFlow(player1, player2)
			elif spellOption == "2":
				print("Total number of cards in the outdated deck is :" + str(len(deck)))
				player2ResurrectSpeell = random.randint(1, len(deck))
				player2.CardDetails.insert(0, deck[int(player2ResurrectSpeell) - 1])
				player2.CardCount = 1
				normalFlow(player1, player2)
			else:
				print("Invalid input")
				return False
		elif player2.WonRound:
			if machineGame:
				spellOption = str(random.randint(1, 2))
			else:
				print(
					"Do you wish {0} to go for normal flow or chose the Resurrect Spell Choice? Enter values 1 or 2 respectively".format(
						player1.Name))
				spellOption = input()

			if spellOption == "1":
				normalFlow(player1, player2)
			elif spellOption == "2":
				print("Total number of cards in the outdated deck is :" + str(len(deck)))
				player1ResurrectSpeell = random.randint(1, len(deck))
				player1.CardDetails.insert(0, deck[int(player1ResurrectSpeell) - 1])
				player1.CardCount = 1
				normalFlow(player1, player2)
			else:
				print("Invalid input")
				return False
		else:
			print("Game ended")
			return False

	except Exception as ex:
		print("Something went wrong: " + str(ex))
		raise Exception("Something went wrong in callResurrectSpell")

	logging.info("callResurrectSpell Ended")
	return True
#endregion


#region Calling Normal Flow logic with game Design


def normalFlow(player1, player2):
	logging.info("normalFlow Started")
	try:
		player1Cards = player1.CardDetails
		player2Cards = player2.CardDetails

		if player1.WonRound and len(player1Cards) > 0 and len(player2Cards) > 0:
			playersDetails = ''
			playersDetails += player1.Name.upper()
			playersDetails += ':' + player1Cards[0].Name + ':' + player1Cards[0].Value
			print('Player 1:', playersDetails)

			playersDetails = ''
			playersDetails += player2.Name.upper()
			playersDetails += ':' + player2Cards[0].Name + ':' + player2Cards[0].Value
			print('Player 2:', playersDetails)

			if int(player1Cards[0].Value) > int(player2Cards[0].Value):
				print("{0} - Player 1 has win the round.".format(player1.Name))
				player1.Ponits += 1
				player1.WonRound = True
				player2.WonRound = False
			elif int(player1Cards[0].Value) < int(player2Cards[0].Value):
				print("{0} - Player 2 has win the round.".format(player2.Name))
				player2.Ponits += 1
				player2.WonRound = True
				player1.WonRound = False

			deck.append(player1Cards[0])
			deck.append(player2Cards[0])

		elif player2.WonRound and len(player1Cards) > 0 and len(player2Cards) > 0:
			playersDetails = ''
			playersDetails += player2.Name.upper()
			playersDetails += ':' + player2Cards[0].Name + ':' + player2Cards[0].Value
			print('Player 2:', playersDetails)

			playersDetails = ''
			playersDetails += player1.Name.upper()
			playersDetails += ':' + player1Cards[0].Name + ':' + player1Cards[0].Value
			print('Player 1:', playersDetails)

			if int(player2Cards[0].Value) > int(player1Cards[0].Value):
				print("{0} - Player 2 has win the round.".format(player2.Name))
				player2.Ponits += 1
				player1.WonRound = False
				player2.WonRound = True

			elif int(player2Cards[0].Value) < int(player1Cards[0].Value):
				print("{0} - Player 1 has win the round.".format(player1.Name))
				player1.Ponits += 1
				player1.WonRound = True
				player2.WonRound = False

			deck.append(player2Cards[0])
			deck.append(player1Cards[0])

		elif len(player1Cards) == 0 or len(player2Cards) == 0:
			print("Game Over")

		else:
			print("Invalid valid card")
			return False

		print("{0} - Player1: Remaining cards count: {1}, and points: {2}".format(player1.Name, str(len(player1Cards) - 1),
																			  player1.Ponits))
		print("{0} - Player2: Remaining cards count: {1}, and points: {2}".format(player2.Name, str(len(player2Cards) - 1),
																			  player2.Ponits))
	except Exception as ex:
		print("Something went wrong: " + str(ex))
		raise Exception("Something went wrong in normalFlow")

	logging.info("normalFlow Ended")
	return True

#endregion


#region Actual Game play started. Game Design


def gamePlayBegin(dieWinPlayer):
	logging.info("gamePlayBegin Started")
	try:
		player1, player2 = players
		iscompleted = False
		if dieWinPlayer == player1.Id:
			print("{0} - Player 1 Started the Game ".format(player1.Name))
			cardCount = len(player1.CardDetails)
			player1.WonRound = True
			player2.WonRound = False
			cardCount = cardCount + player1.CardCount

			while cardCount > 0 and len(player2.CardDetails) > 0:
				label: start
				spell = spellCheckCondition(player1, player2)
				label: end

				if spell == "1":
					iscompleted = callGodSpell(player1, player2)
					cardCount = cardCount + player2.CardCount + player1.CardCount
					if player2.WonRound:
						goto: begin
				elif spell == "2":
					if len(deck) > 0:
						iscompleted = callResurrectSpell(player1, player2)
						cardCount = cardCount + player2.CardCount + player1.CardCount
						if player2.WonRound:
							goto: begin
				elif spell == "3":
					print("Normal Flow Called")
					iscompleted = normalFlow(player1, player2)
					if player2.WonRound:
						goto: begin
				else:
					print("Enter the correct input")

				if iscompleted:
					if len(deck) > 0:
						random.shuffle(deck)
					if len(player1.CardDetails) > 0:
						del player1.CardDetails[0]
					if len(player2.CardDetails) > 0:
						del player2.CardDetails[0]
					cardCount -= 1

				player1.CardCount = 0
				player2.CardCount = 0
				goto: end

		elif dieWinPlayer == player2.Id:
			print("{0} - Player 2 Started the Game ".format(player2.Name))
			cardCount = len(player2.CardDetails)
			player2.WonRound = True
			player1.WonRound = False
			cardCount = cardCount + player2.CardCount

			while cardCount > 0 and len(player1.CardDetails) > 0:
				if machineGame:
					spell = str(random.randint(1, 3))
				else:
					label: begin
					spell = spellCheckCondition(player1, player2)
					label: end
				if spell == "1":
					iscompleted = callGodSpell(player1, player2)
					cardCount = cardCount + player2.CardCount + player1.CardCount
					if player1.WonRound:
						goto: begin
				elif spell == "2":
					if len(deck) > 0:
						iscompleted = callResurrectSpell(player1, player2)
						cardCount = cardCount + player2.CardCount + player1.CardCount
						if player1.WonRound:
							goto: begin
				elif spell == "3":
					iscompleted = normalFlow(player1, player2)
					if player1.WonRound:
						goto: begin
				else:
					print("Enter the correct input")

				if iscompleted:
					if len(player1.CardDetails) > 0:
						del player1.CardDetails[0]
					if len(player2.CardDetails) > 0:
						del player2.CardDetails[0]

					cardCount -= 1
				if len(deck) > 0:
					random.shuffle(deck)

				player1.CardCount = 0
				player2.CardCount = 0
				goto: end
	except Exception as ex:
		print("Something went wrong: " + str(ex))
		raise Exception("Something went wrong in normalFlow")

	logging.info("gamePlayBegin ended")

#endregion


#region Human to Human play logic


def func_Human_Human():
	try:
		logging.info("func_Human_Human Started")
		print("Enter the player 1 Name")
		name = input()
		players.append(Player(name, 1))

		print("Enter the player 2 Name")
		name = input()
		players.append(Player(name, 2))

		# Logic for Die rolling
		dieWinPlayer = dieRollingForPlayers()

		print("Total number of cards in the Deck:" + str(len(cards)))
		distributeCards()

		gamePlayBegin(dieWinPlayer)

		player1, player2 = players
		if player1.Ponits > player2.Ponits:
			print("Player1, {0} has won the Game".format(player1.Name))
		elif player1.Ponits < player2.Ponits:
			print("Player2, {0} has won the Game".format(player2.Name))
		elif player1.Ponits == player2.Ponits:
			print("Player1,Player {0}:{1} has Game Draw".format(player1.Name, player2.Name))

	except Exception as ex:
		print("Something went wrong: " + str(ex))
		raise Exception("Something went wrong in func_Human_Human")

	logging.info("func_Human_Human Ended")

#endregion


#region Human to Machine play logic


def func_Human_Machine():
	try:
		print("Enter the player 1 Name")
		name = input()
		players.append(Player(name, 1))

		print("Welcome {0} !. My name is Sankar Chinna Shanmugam. I am your opponent and automatic player 2")
		players.append(Player("Sankar Chinna Shanmugam", 2))

		# Logic for Die rolling
		dieWinPlayer = dieRollingForPlayers()

		print("Total number of cards in the Deck:" + str(len(cards)))
		distributeCards()

		gamePlayBegin(dieWinPlayer)

		player1, player2 = players
		if player1.Ponits > player2.Ponits:
			print("Player1, {0} has won the Game".format(player1.Name))
		elif player1.Ponits < player2.Ponits:
			print("Player2, {0} has won the Game".format(player2.Name))
		elif player1.Ponits == player2.Ponits:
			print("Player1,Player {0}:{1} has Game Draw".format(player1.Name, player2.Name))

	except Exception as ex:
		print("Something went wrong: " + str(ex))
		raise Exception("Something went wrong in func_Human_Human")

	logging.info("func_Human_Machine Ended")

#endregion


#region Main method

print("Welcome to the Card Game")
print("Press 1 to Continue with Human to Human Play and Press 2 to Human to Machine Play")
try:
	hToH = input()
	if hToH == "1":
		func_Human_Human()
	elif hToH == "2":
		machineGame = True
		func_Human_Machine()
	else:
		print("Please enter valid input either 1 or 2")

except Exception as ex:
	print("Something went wrong, please try again...! For more information check the log files." + str(ex))
finally:
	print("Game completed ")

# endregion
