class Card:
    def __init__(self, Name, Id, Value):
        self.Name = Name
        self.Id = Id
        self.Value = Value



