
from Card import Card


class Player:
    def __init__(self, Name, Id):
        self.Name = Name
        self.Id = Id
        self.CardDetails = []
        self.Ponits = 0
        self.WonRound = False
        self.CardCount = 0
        self.ResurrectSpellCount = 0
        self.GodSpellCount = 0