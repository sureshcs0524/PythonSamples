#region import
import sys
sys.path.append ('/Users/clanc/Documents/Development/')
import re #Importing the regular expressions
import logging #Importing the Logger to find run time information
#endregion


#region custom funtions
#Validating the input parameters 

def fun_Input_Validation(FirstString, SecondString):
    print("Method input_Validation Entered")
    logging.info("fun_Input_Validation Started")
    
    if FirstString is "":
        print("Input mandatory filed not passed")
        logging.warning("Input one is empty")
        raise Exception("Input values is mandatory")
        #raise Exception('general exceptions not caught by specific handling')

    if not re.match("^[A-Za-z]*$", FirstString):
        print ("Error! Make sure you only use letters in first string")
        raise Exception("Make sure you only use letters in first string")

    if SecondString is "":
        print("Input mandatory filed not passed")
        logging.warning("Input two is empty")
        raise Exception("Input values is mandatory")

    if not re.match("^[A-Za-z]*$", SecondString):
        print ("Error! Make sure you only use letters in second string")
        raise Exception("Make sure you only use letters in second string")
    
    logging.info("fun_Input_Validation Completed")
    print("Method input_Validation Exited")

#Writing the funtion which takes the two inputs and returns the LCS value
def fun_LCS(FirstString, SecondString):
    logging.info("fun_LCS Started")
    array_Double = [["" for x in range(len(SecondString))] for x in range(len(FirstString))]
    for i in range(len(FirstString)):
        for j in range(len(SecondString)):
            if FirstString[i] == SecondString[j]:
                if i == 0 or j == 0:
                    array_Double[i][j] = FirstString[i]
                else:
                    array_Double[i][j] = array_Double[i-1][j-1] + FirstString[i]
            else:
                array_Double[i][j] = max(array_Double[i-1][j], array_Double[i][j-1], key=len)

    LCS = array_Double[-1][-1]
    logging.info("fun_LCS Completed")
    return LCS    
    
#endregion
    
#region Main method
print ( "Welcome to Longest Common Subsequence finding between two strings" )
print("Program Started")
str_FirstString="FirstString"
str_SecondString="SecondString"
print( "Enter the Values of Strings" )
print("Enter the first string value")
str_FirstString=raw_input()
str_FirstString=str_FirstString.strip()
print("You have entered first string value as: " + str_FirstString)
print("Enter the second Value")
str_SecondString=raw_input()
str_SecondString=str_SecondString.strip()
print("You have entered second string value as: " + str_SecondString)
print("Validation are started")
try:
    print("Method input_Validation started")
    fun_Input_Validation(str_FirstString, str_SecondString)
    print("Method input_Validation Completed")

    print("Method fun_LCS started")

    lcs = fun_LCS(str_FirstString.lower(), str_SecondString.lower())
    print("The result of the LCS: " + lcs.upper())

    print("Method fun_LCS Completed")      
    
except Exception as ex:
    print("Something went wrong: " + str(ex))
finally:
    print("Program completed ")
    
#endregion
    
    